import React from 'react';

const DiscoverNepal = () => {
    return (
        <section className="relative w-full overflow-hidden py-16 md:py-24">
            {/* Decorative rotated patch, scoped behind the image cluster */}
            <img
                src="/patch3.png"
                alt=""
                aria-hidden="true"
                className="pointer-events-none absolute top-1/2 right-0 -z-10 w-[280px] -translate-y-1/2 rotate-[89.27deg] opacity-90 select-none md:w-[420px] lg:w-[520px]"
            />

            <div className="mx-auto flex max-w-[1440px] flex-col items-center gap-12 px-6 md:flex-row md:gap-16 md:px-12 lg:px-24 bg-[#F9F4F0] md:bg-transparent">
                {/* Mobile: single image first */}
                <div className="w-[95%] md:hidden">
                    <div
                        className="aspect-[336/229] w-full rounded-2xl bg-[#D9D9D9] bg-cover bg-center"
                        style={{
                            backgroundImage: "url('/discover-nepal-2.png')",
                        }}
                    />
                </div>

                {/* Left: heading, copy, CTA */}
                <div className="flex max-w-[605px] flex-1 flex-col items-center gap-6 text-center md:items-start md:text-left">
                    <h2 className="font-manrope text-[24px] leading-[1.05] font-bold text-[#334155] md:text-4xl">
                        Discover the Beauty of Nepal
                    </h2>
                    <p className="font-manrope text-[13px] leading-[1.05] font-normal text-[#334155] md:text-lg">
                        From snow-capped peaks and peaceful lakes to ancient
                        heritage sites and vibrant local communities, Nepal
                        offers experiences unlike anywhere else.
                    </p>

                    {/* Mobile CTA button */}
                    <button className="font-manrope mt-2 flex h-[25px] w-fit items-center justify-center gap-2 rounded-full bg-[#FF7A00] px-3 text-[12px] leading-[16px] font-bold text-white md:hidden">
                        <span className="px-2">Start Your Journey</span>
                    </button>

                    {/* Desktop CTA button */}
                    <button className="font-manrope mt-2 hidden h-[42px] w-fit items-center justify-center gap-2 rounded-full bg-[#2D8A8A] px-3 text-[16px] leading-[22px] font-bold text-white md:flex">
                        <span className="px-2">Start Your Journey</span>
                        <span className="mr-1 flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-[#F7F2EE]">
                            <span className="relative h-[10px] w-[10px]">
                                <span className="absolute top-1/2 left-0 h-px w-full -translate-y-1/2 bg-[#60A5FA]" />
                                <span className="absolute top-0 left-1/2 h-full w-px -translate-x-1/2 bg-[#60A5FA]" />
                            </span>
                        </span>
                    </button>
                </div>

                {/* Desktop: staggered image pair */}
                <div className="hidden w-full flex-1 items-center justify-end gap-4 md:flex md:justify-center md:gap-6">
                    {/* Rectangle 37 — taller, sits higher (offset up) */}
                    <div
                        className="-mt-14 aspect-square w-[257px] rounded-2xl bg-[#D9D9D9] bg-cover bg-center"
                        style={{
                            backgroundImage: "url('/discover-nepal-1.png')",
                        }}
                    />

                    {/* Rectangle 36 — shorter, sits lower */}
                    <div
                        className="aspect-square w-[386px] rounded-2xl bg-[#D9D9D9] bg-cover bg-center"
                        style={{
                            backgroundImage: "url('/discover-nepal-2.png')",
                        }}
                    />
                </div>
            </div>
        </section>
    );
};

export default DiscoverNepal;
