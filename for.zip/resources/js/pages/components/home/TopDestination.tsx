import React from 'react';

const destinations = [
    {
        name: 'Tilicho Lake',
        image: '/Group_35.png',
        ratio: '258 / 391',
        raised: true,
        size: 'md',
    },
    {
        name: 'Everest',
        image: '/Group_36.png',
        ratio: '258 / 391',
        raised: false,
        size: 'lg',
    },
    {
        name: 'Gokyo Lake',
        image: '/Group_37.png',
        ratio: '258 / 391',
        raised: true,
        size: 'md',
    },
];

const TopDestinations = () => {
    return (
        <section
            className="w-full"
            style={{ padding: 'clamp(2rem, 6vw, 6rem) clamp(1rem, 5vw, 6rem)' }}
        >
            <div
                className="mx-auto flex flex-col items-center"
                style={{ maxWidth: 1200, gap: 'clamp(2rem, 5vw, 4rem)' }}
            >
                <h2
                    className="font-manrope text-center font-bold text-[#334155]"
                    style={{
                        fontSize: 'clamp(24px, 4vw, 36px)',
                        lineHeight: 1.05,
                        maxWidth: 342,
                    }}
                >
                    Explore Nepal's Top Destinations
                </h2>

                {/* MOBILE: 4 small cards in a row */}
                <div className="flex w-full justify-center gap-0 md:hidden">
                    {destinations.map((dest) => (
                        <div
                            key={dest.name}
                            className="flex flex-col items-center"
                        >
                            <div
                                className="h-[97px] w-[117px] rounded-t-[5px] bg-[#D9D9D9] bg-cover bg-center"
                                style={{
                                    backgroundImage: `url(${dest.image})`,
                                }}
                            />
                            <div className="flex h-[37px] w-[117px] items-center justify-center rounded-b-[5px] bg-white shadow-[0px_4px_4px_rgba(0,0,0,0.25)]">
                                <span
                                    className="font-manrope font-bold text-[#253A55]"
                                    style={{
                                        fontSize: 10,
                                        lineHeight: '14px',
                                        letterSpacing: '0.03em',
                                    }}
                                >
                                    {dest.name}
                                </span>
                            </div>
                        </div>
                    ))}
                </div>

                {/* DESKTOP: horizontal scroll-snap carousel */}
                <div
                    className="-mx-6 hidden w-full snap-x snap-mandatory [scrollbar-width:none] items-end gap-4 overflow-x-auto px-6 [-ms-overflow-style:none] md:flex md:snap-none md:gap-6 md:overflow-visible md:px-0 [&::-webkit-scrollbar]:hidden"
                    style={{
                        gridTemplateColumns:
                            'repeat(auto-fit, minmax(220px, 1fr))',
                    }}
                >
                    {destinations.map((dest) => (
                        <div
                            key={dest.name}
                            className={`relative shrink-0 snap-center overflow-hidden rounded-2xl bg-[#D9D9D9] bg-cover bg-center ${dest.size === 'lg' ? 'w-auto' : 'w-auto'} `}
                            style={{
                                aspectRatio: dest.ratio,
                                backgroundImage: `url(${dest.image})`,
                                transform: dest.raised
                                    ? 'translateY(clamp(-16px, -2vw, 0px))'
                                    : 'none',
                            }}
                        >
                            <div className="absolute inset-0 bg-linear-to-b from-black/40 via-black/0 to-black/10" />
                            <span
                                className="font-manrope absolute right-0 left-0 text-center font-medium text-white"
                                style={{
                                    top: '6%',
                                    fontSize: 'clamp(14px, 2vw, 24px)',
                                }}
                            >
                                {dest.name}
                            </span>
                        </div>
                    ))}
                </div>
            </div>
        </section>
    );
};

export default TopDestinations;
