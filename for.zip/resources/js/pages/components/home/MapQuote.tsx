// components/home/MapQuote.jsx
import React from 'react';

export default function MapQuote() {
    return (
        <div className="flex w-full justify-center px-6 md:px-0">
            <p className="font-manrope w-full max-w-[1011px] text-center text-xl leading-[1.3] font-medium text-[#334155] sm:text-2xl md:text-3xl md:leading-[44px] lg:text-[32px]">
                "Between 80°E and 88°E longitude lies the world's most vertical
                country — a land containing everything from tiger-haunted jungle
                to the roof of the world, compressed into a strip of earth 800
                kilometres wide."
            </p>
        </div>
    );
}
