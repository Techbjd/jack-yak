import Header from '../shared/Header';
import { Plus } from 'lucide-react';

export default function Hero() {
  return (
    <div className="relative w-full h-full md:aspect-4/3 bg-[#0E1B2B] [overflow-x:clip] [overflow-y:visible]">

      {/* Background image */}
      <img
        src="/Hero-bg.png"
        alt="hero background"
        className="absolute inset-0 w-full h-full object-cover object-center z-0"
      />

      {/* Gradient overlay */}
      <div className="absolute inset-0 bg-linear-to-r from-[#253A55] to-[#5180BB] opacity-40 blur-[40px] sm:blur-[70px] lg:blur-[100.9px] z-10" />

      {/* Header */}
      <div className="absolute top-0 inset-x-0 z-30">
        <Header />
      </div>

      {/* Hero text content */}
      <div className="absolute inset-x-0 z-20 flex flex-col items-start text-white
                      min-w-0
                      px-4 sm:px-6 md:px-10 lg:pl-27.25
                      top-[max(14%,92px)] sm:top-[max(16%,96px)] lg:top-[17.5%]
                      max-w-full lg:max-w-225">

        <h1 className="font-manrope font-extrabold
                        text-[clamp(1.15rem,7vw,6rem)]
                        leading-[1.15] sm:leading-tight break-words max-w-full">
          The World Above the Clouds
        </h1>

        <div className="w-6 sm:w-8 h-0 border-t-[3px] sm:border-t-[5px] border-white my-2.5 sm:my-6 lg:my-8" />

        <p className="max-w-full sm:max-w-[538px] font-manrope font-bold
                      text-xs sm:text-xl lg:text-2xl leading-snug sm:leading-snug">
          Nestled in the heart of the Himalayas, Nepal is a land of majestic
          mountains, rich heritage, and adventures unlike anywhere else.
        </p>

        <button className="mt-3 sm:mt-6 h-[34px] sm:h-[42px] px-3 sm:px-4 rounded-full bg-[#2D8A8A]
                           flex items-center gap-1.5 sm:gap-2 font-manrope font-bold
                           text-white text-xs sm:text-base shrink-0">
          <span>Explore Nepal</span>
          <span className="bg-[#F7F2EE] rounded-full w-6 h-6 sm:w-8 sm:h-8 flex items-center justify-center shrink-0">
            <Plus className="w-2.5 h-2.5 sm:w-3 sm:h-3 text-[#60A5FA]" strokeWidth={3} />
          </span>
        </button>
      </div>

      {/* Decorative patch images — bleed downward only, never sideways */}
      <img
        src="/patch1-left.png"
        alt=""
        className="absolute z-10 pointer-events-none
                   left-0 top-[65%]
                   w-[59%] max-w-[59%] h-auto
                   object-contain object-top"
      />
      <img
        src="/patch1-right.png"
        alt=""
        className="absolute z-10 pointer-events-none
                   right-0 top-[63%]
                   w-[59%] max-w-[59%] h-auto
                   object-contain object-top-right"
      />
    </div>
  );
}
