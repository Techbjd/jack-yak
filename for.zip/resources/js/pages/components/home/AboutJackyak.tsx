import React from 'react';

const AboutJackyak = () => {
    return (
        <section className="relative w-full overflow-hidden py-16 md:py-24">
            <img
                src="/patch2.png"
                alt=""
                aria-hidden="true"
                className="pointer-events-none absolute -top-10 -left-32 -z-10 w-[280px] opacity-90 select-none md:-top-16 md:-left-24 md:w-[420px] lg:w-[520px]"
            />

            <div className="mx-auto flex max-w-[1440px] flex-col gap-16 px-6 md:gap-24 md:px-12 lg:px-24 bg-[#F9F4F0]">
                {/* About text */}
                <div className="flex flex-col items-center gap-6 text-center md:flex-row md:items-center md:gap-16 md:text-left">
                    <div className="flex max-w-[575px] flex-1 flex-col gap-6">
                        <h2 className="font-manrope text-[20px] leading-[1.05] font-bold text-[#334155] uppercase md:text-4xl">
                            About Jackyak
                        </h2>
                        <p className="font-manrope text-[13px] leading-[1.05] font-normal text-[#334155] md:text-2xl">
                            JackYak is your trusted travel companion for
                            exploring Nepal. Discover curated trekking
                            itineraries, hidden destinations, local culture, and
                            unforgettable adventures—from the Himalayas to the
                            Terai. From Everest to the Terai, experience Nepal
                            through carefully crafted journeys.
                        </p>
                    </div>

                    {/* Desktop image */}
                    <div className="hidden w-full flex-1 justify-end md:block">
                        <div
                            className="mx-auto aspect-[590/287] w-full max-w-[590px] rounded-[17px] bg-[#D9D9D9] bg-cover bg-center md:mx-0 md:ml-auto"
                            style={{
                                backgroundImage: "url('/aboutJackyak.png')",
                            }}
                        />
                    </div>
                </div>

                {/* Mobile: Popular Destinations → Image → Travel Tips */}
                <div className="flex flex-col items-center gap-10 md:hidden">
                    <div className="flex max-w-[575px] flex-col gap-4 text-center">
                        <h3 className="font-manrope text-[20px] leading-[1.05] font-bold text-[#334155]">
                            Popular Destinations
                        </h3>
                        <p className="font-manrope text-[13px] leading-[1.05] font-normal text-[#334155]">
                            Discover breathtaking mountains, serene lakes,
                            ancient heritage sites, lush national parks, and
                            vibrant cities across Nepal. Every destination
                            offers a unique adventure waiting to be explored.
                        </p>
                    </div>

                    <div
                        className="aspect-[333/162] w-full max-w-[333px] rounded-[17px] bg-[#D9D9D9] bg-cover bg-center"
                        style={{
                            backgroundImage: "url('/aboutJackyak.png')",
                        }}
                    />

                    <div className="flex max-w-[575px] flex-col gap-4 text-center">
                        <h3 className="font-manrope text-[24px] leading-[1.05] font-bold text-[#334155]">
                            Travel Tips
                        </h3>
                        <p className="font-manrope text-[13px] leading-[1.05] font-normal text-[#334155]">
                            Find essential information on the best seasons to
                            visit, packing guides, permits, transportation,
                            budgeting, and safety tips before you travel.
                        </p>
                    </div>
                </div>

                {/* Desktop: Popular Destinations + Travel Tips side by side */}
                <div className="hidden md:grid md:grid-cols-2 md:gap-16">
                    <div className="flex max-w-[575px] flex-col gap-4 text-left">
                        <h3 className="font-manrope text-4xl leading-[1.05] font-bold text-[#334155]">
                            Popular Destinations
                        </h3>
                        <p className="font-manrope text-2xl leading-[1.05] font-normal text-[#334155]">
                            Discover breathtaking mountains, serene lakes,
                            ancient heritage sites, lush national parks, and
                            vibrant cities across Nepal. Every destination
                            offers a unique adventure waiting to be explored.
                        </p>
                    </div>

                    <div className="flex max-w-[575px] flex-col gap-4 text-left bg-white">
                        <h3 className="font-manrope text-4xl leading-[1.05] font-bold text-[#334155]">
                            Travel Tips
                        </h3>
                        <p className="font-manrope text-2xl leading-[1.05] font-normal text-[#334155]">
                            Find essential information on the best seasons to
                            visit, packing guides, permits, transportation,
                            budgeting, and safety tips before you travel.
                        </p>
                    </div>
                </div>
            </div>
        </section>
    );
};

export default AboutJackyak;
