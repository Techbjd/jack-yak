import { Head } from '@inertiajs/react';
import Hero from './components/home/Hero';
import NepalMap from './components/home/NepalMap';
import MapQuote from './components/home/MapQuote';
import AboutJackyak from './components/home/AboutJackyak';
import DiscoverNepal from './components/home/DiscoverNepal';
import TopDestinations from './components/home/TopDestination';
import Footer from './components/shared/Footer';

export default function Home() {
    return (
        <div className="mx-auto flex w-360 flex-col items-center justify-center sm:max-w-full">
            <Hero />
            <div className="mt-24 flex max-h-300 flex-col items-center gap-16 md:mt-39 md:gap-65">
                <NepalMap />
                <MapQuote />
            </div>
            <AboutJackyak />
            <div className='hidden md:block'>
            <img
                src="/Mountain.png"
                alt="Mountain Image"
                className="object-fit m-auto h-auto w-full px-2 "
            />
            </div>
            <DiscoverNepal />
            <TopDestinations />
            <Footer />
        </div>
    );
}
